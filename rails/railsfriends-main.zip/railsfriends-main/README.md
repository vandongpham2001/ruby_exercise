# Friends List App

Hello my name is John Elder and I work at Codemy.com

This is my Ruby on Rails Friends List App!

Follow me at Codemy.com

