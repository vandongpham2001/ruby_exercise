class Sach < ApplicationRecord
end
